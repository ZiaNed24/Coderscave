
# App clon Netflix
React app with TypeScript, Style Components, responsive designe.

# Api Reference

MovieDB


# Deploy in Firebase

https://dario-netflix.firebaseapp.com/

## Install

```
yarn
```

## Run for development

```
yarn start
```

## Build to production

```
yarn build
```

## Screenshot

![Screen Shot 2022-10-05 at 13 07 11](https://user-images.githubusercontent.com/63020855/194119974-eacbe85d-0f16-433e-9857-f0d220ed4f2e.png)

![Screen Shot 2022-10-05 at 13 08 34](https://user-images.githubusercontent.com/63020855/194120223-9e7ea5d9-4698-41db-b753-4ecd51352cf4.png)

![Screen Shot 2022-10-05 at 12 59 03](https://user-images.githubusercontent.com/63020855/194118454-9c8daa20-8169-4cd4-892b-aa75c3849612.png)

## Authors

- [@hdariodev](https://www.hdariodev.com)
