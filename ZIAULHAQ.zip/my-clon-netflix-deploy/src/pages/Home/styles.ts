import styled from "styled-components"

export const Home = styled.div`
    color: white;
    background-color: #0b0b0b;
    overflow: hidden;
`