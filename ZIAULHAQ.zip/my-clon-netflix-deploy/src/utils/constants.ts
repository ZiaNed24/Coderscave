
export const MOVIES_TITLE = [
    'https://occ-0-3111-2433.1.nflxso.net/dnm/api/v6/LmEnxtiAuzezXBjYXPuDgfZ4zZQ/AAAABSYkfln-wVEwKGG0OCP9i5Mg3G93Df45g7a9OGbh8ywlJr2ZekWHGmimiywRh3vw_Vk-qVWiji1naEBuNHLm9bmN4OeqiDD1SKbvmXejjC11.png?r=d4b',
    'https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/a58a7719-0dcf-4e0b-b7bb-d2b725dbbb8e/deoreyb-22a5b18e-6527-46fc-9a1b-eafbbc0769b0.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcL2E1OGE3NzE5LTBkY2YtNGUwYi1iN2JiLWQyYjcyNWRiYmI4ZVwvZGVvcmV5Yi0yMmE1YjE4ZS02NTI3LTQ2ZmMtOWExYi1lYWZiYmMwNzY5YjAucG5nIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.snyP09oIg77UvQXGQ7XpQhkymt--y4aQnRS0mRsrtFQ',
    'https://www.dafont.com/forum/attach/orig/9/9/991799.png?1',
    'https://www.pngplay.com/wp-content/uploads/7/Money-Heist-TV-Series-Transparent-PNG.png'
]

export const MOVIES_BG = [
    'https://surtido.pe/wp-content/uploads/2021/05/Shingeki-no-kyojin-Endo-obu-za-warudo-netflix-peliculas-trailers-live-action-1024x576.jpg',
    'https://i0.wp.com/www.gamerfocus.co/wp-content/uploads/2020/09/stranger_things_1.png?fit=1490%2C877&ssl=1',
    'https://nosomosnonos.com/wp-content/uploads/2021/11/alice-in-borderland-serie.jpg',
    'https://media.revistagq.com/photos/6135d8c73bc2dbd6357b63a2/3:2/w_1602,h_1068,c_limit/la-casa-de-papel-2.jpg'

]